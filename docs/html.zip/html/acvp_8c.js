var acvp_8c =
[
    [ "acvp_create_test_session", "acvp_8c.html#afbb68e9ad0690b3e037e7938a2a6e131", null ],
    [ "acvp_enable_capability", "acvp_8c.html#a5acf551dfd466c33bfa9950a84dc6e97", null ],
    [ "acvp_free_test_session", "acvp_8c.html#a381b2f31ae652a060549f475f0b5fe57", null ],
    [ "acvp_process_tests", "acvp_8c.html#a4a3c3c9a9c42973fd8d23b687211683c", null ],
    [ "acvp_register", "acvp_8c.html#a3702d8a5303ede3c2d669c7b7bd20540", null ],
    [ "acvp_retry_handler", "acvp_8c.html#afb0c7050f33678a55505ed54138eb27e", null ],
    [ "acvp_set_cacerts", "acvp_8c.html#a429e68701f9c17543343c92e74948be0", null ],
    [ "acvp_set_certkey", "acvp_8c.html#a5129867659ea11f6dcf95fefdc373c7b", null ],
    [ "acvp_set_path_segment", "acvp_8c.html#a10afc723bb4a375a3bcbeeaec29dd87a", null ],
    [ "acvp_set_server", "acvp_8c.html#a22013f98bbcb8d0ba89ff2c32f440aa2", null ]
];