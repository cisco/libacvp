var searchData=
[
  ['acvp_2ec',['acvp.c',['../acvp_8c.html',1,'']]],
  ['acvp_2eh',['acvp.h',['../acvp_8h.html',1,'']]],
  ['acvp_5fasym_5fcipher_5ftc_5ft',['acvp_asym_cipher_tc_t',['../structacvp__asym__cipher__tc__t.html',1,'']]],
  ['acvp_5fcipher_5ftc_5ft',['acvp_cipher_tc_t',['../structacvp__cipher__tc__t.html',1,'']]],
  ['acvp_5fcreate_5ftest_5fsession',['acvp_create_test_session',['../acvp_8c.html#afbb68e9ad0690b3e037e7938a2a6e131',1,'acvp_create_test_session(ACVP_CTX **ctx, ACVP_RESULT(*progress_cb)(char *msg)):&#160;acvp.c'],['../acvp_8h.html#afbb68e9ad0690b3e037e7938a2a6e131',1,'acvp_create_test_session(ACVP_CTX **ctx, ACVP_RESULT(*progress_cb)(char *msg)):&#160;acvp.c']]],
  ['acvp_5fctx',['ACVP_CTX',['../struct_a_c_v_p___c_t_x.html',1,'']]],
  ['acvp_5fenable_5fcapability',['acvp_enable_capability',['../acvp_8c.html#a5acf551dfd466c33bfa9950a84dc6e97',1,'acvp_enable_capability(ACVP_CTX *ctx, ACVP_CIPHER cipher, ACVP_CIPHER_MODE mode, ACVP_CIPHER_OP op, ACVP_RESULT(*crypto_handler)(ACVP_CIPHER_TC *test_case)):&#160;acvp.c'],['../acvp_8h.html#a5acf551dfd466c33bfa9950a84dc6e97',1,'acvp_enable_capability(ACVP_CTX *ctx, ACVP_CIPHER cipher, ACVP_CIPHER_MODE mode, ACVP_CIPHER_OP op, ACVP_RESULT(*crypto_handler)(ACVP_CIPHER_TC *test_case)):&#160;acvp.c']]],
  ['acvp_5fentropy_5ftc_5ft',['acvp_entropy_tc_t',['../structacvp__entropy__tc__t.html',1,'']]],
  ['acvp_5ffree_5ftest_5fsession',['acvp_free_test_session',['../acvp_8c.html#a381b2f31ae652a060549f475f0b5fe57',1,'acvp_free_test_session(ACVP_CTX *ctx):&#160;acvp.c'],['../acvp_8h.html#a381b2f31ae652a060549f475f0b5fe57',1,'acvp_free_test_session(ACVP_CTX *ctx):&#160;acvp.c']]],
  ['acvp_5fprocess_5ftests',['acvp_process_tests',['../acvp_8c.html#a4a3c3c9a9c42973fd8d23b687211683c',1,'acvp_process_tests(ACVP_CTX *ctx):&#160;acvp.c'],['../acvp_8h.html#a4a3c3c9a9c42973fd8d23b687211683c',1,'acvp_process_tests(ACVP_CTX *ctx):&#160;acvp.c']]],
  ['acvp_5fregister',['acvp_register',['../acvp_8c.html#a3702d8a5303ede3c2d669c7b7bd20540',1,'acvp_register(ACVP_CTX *ctx):&#160;acvp.c'],['../acvp_8h.html#a3702d8a5303ede3c2d669c7b7bd20540',1,'acvp_register(ACVP_CTX *ctx):&#160;acvp.c']]],
  ['acvp_5fresult',['ACVP_RESULT',['../struct_a_c_v_p___r_e_s_u_l_t.html',1,'']]],
  ['acvp_5fset_5fcacerts',['acvp_set_cacerts',['../acvp_8c.html#a429e68701f9c17543343c92e74948be0',1,'acvp_set_cacerts(ACVP_CTX *ctx, char *ca_file):&#160;acvp.c'],['../acvp_8h.html#a429e68701f9c17543343c92e74948be0',1,'acvp_set_cacerts(ACVP_CTX *ctx, char *ca_file):&#160;acvp.c']]],
  ['acvp_5fset_5fcertkey',['acvp_set_certkey',['../acvp_8c.html#a5129867659ea11f6dcf95fefdc373c7b',1,'acvp_set_certkey(ACVP_CTX *ctx, char *cert_file, char *key_file):&#160;acvp.c'],['../acvp_8h.html#a5129867659ea11f6dcf95fefdc373c7b',1,'acvp_set_certkey(ACVP_CTX *ctx, char *cert_file, char *key_file):&#160;acvp.c']]],
  ['acvp_5fset_5fpath_5fsegment',['acvp_set_path_segment',['../acvp_8c.html#a10afc723bb4a375a3bcbeeaec29dd87a',1,'acvp_set_path_segment(ACVP_CTX *ctx, char *path_segment):&#160;acvp.c'],['../acvp_8h.html#a10afc723bb4a375a3bcbeeaec29dd87a',1,'acvp_set_path_segment(ACVP_CTX *ctx, char *path_segment):&#160;acvp.c']]],
  ['acvp_5fset_5fserver',['acvp_set_server',['../acvp_8c.html#a22013f98bbcb8d0ba89ff2c32f440aa2',1,'acvp_set_server(ACVP_CTX *ctx, char *server_name, int port):&#160;acvp.c'],['../acvp_8h.html#a22013f98bbcb8d0ba89ff2c32f440aa2',1,'acvp_set_server(ACVP_CTX *ctx, char *server_name, int port):&#160;acvp.c']]],
  ['acvp_5fsym_5fcipher_5ftc_5ft',['acvp_sym_cipher_tc_t',['../structacvp__sym__cipher__tc__t.html',1,'']]]
];
