/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "libacvp", "index.html", [
    [ "Data Structures", "annotated.html", [
      [ "Overview", "index.html#autotoc_md2", null ],
      [ "Dependencies", "index.html#autotoc_md3", null ],
      [ "Building", "index.html#autotoc_md4", [
        [ "License", "index.html#autotoc_md0", null ],
        [ "Recent Changes!", "index.html#autotoc_md1", [
          [ "To build for runtime testing", "index.html#autotoc_md5", null ],
          [ "To build for non-runtime testing", "index.html#autotoc_md6", null ],
          [ "Cross Compiling", "index.html#autotoc_md7", null ]
        ] ]
      ] ],
      [ "Windows", "index.html#autotoc_md8", null ],
      [ "Running", "index.html#autotoc_md9", null ],
      [ "Testing", "index.html#autotoc_md11", null ],
      [ "Contributing", "index.html#autotoc_md12", null ],
      [ "FAQ", "index.html#autotoc_md13", null ],
      [ "Credits", "index.html#autotoc_md14", null ],
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"acvp_8c.html",
"acvp_8h.html#a4d2f4ca45ed88ed9dbbab295baaf73bea16606425ae4174ee3480087fb1c5e8e6",
"acvp_8h.html#a9c5417e171004a7e9afe81cee31323b8",
"struct_a_c_v_p___k_a_s___e_c_c___m_o_d_e.html",
"structacvp__kdf135__ikev2__tc__t.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';