var searchData=
[
  ['acvp_5fkdf108_5ffixed_5fdata_5fmax_428',['ACVP_KDF108_FIXED_DATA_MAX',['../acvp_8h.html#a5f35880db827ed7b918c27129185ff25',1,'acvp.h']]],
  ['acvp_5fkdf108_5fkeyout_5fmax_429',['ACVP_KDF108_KEYOUT_MAX',['../acvp_8h.html#ab55f9c835655928496c457ed858e952d',1,'acvp.h']]]
];
