var structacvp__kas__ecc__tc__t =
[
    [ "chash", "structacvp__kas__ecc__tc__t.html#a8e4b5fb4ddd9a27fbc16f6777802240a", null ],
    [ "chashlen", "structacvp__kas__ecc__tc__t.html#a4c31b25e5d27226570cb8d40a1e3c5f3", null ],
    [ "cipher", "structacvp__kas__ecc__tc__t.html#a75a4a0af12b65d03933e6837649bfd67", null ],
    [ "curve", "structacvp__kas__ecc__tc__t.html#aa7978ecfeaafd624eca35d005451c0eb", null ],
    [ "d", "structacvp__kas__ecc__tc__t.html#afad87c230201dac06d616d41b2635c3d", null ],
    [ "dlen", "structacvp__kas__ecc__tc__t.html#a142672f9be33d53e1ecf96db7104a396", null ],
    [ "func", "structacvp__kas__ecc__tc__t.html#a6ad9139028d6335d3ea438f2291d3ec5", null ],
    [ "md", "structacvp__kas__ecc__tc__t.html#a2f019f395a1ab711c78806376b9c63b1", null ],
    [ "mode", "structacvp__kas__ecc__tc__t.html#a5f552da5cc8aac04cfcf8502d7feadaf", null ],
    [ "pix", "structacvp__kas__ecc__tc__t.html#a2cc11ae5a2837b6ea55960f9c9a179d1", null ],
    [ "pixlen", "structacvp__kas__ecc__tc__t.html#a367586f214db5b218709487d51b39544", null ],
    [ "piy", "structacvp__kas__ecc__tc__t.html#ac5006c97c9fe8db405bece254ea33a47", null ],
    [ "piylen", "structacvp__kas__ecc__tc__t.html#ad287a26ee4e5e128374edf178e23b56c", null ],
    [ "psx", "structacvp__kas__ecc__tc__t.html#af95ef01d216357b76b15f5205ac9535e", null ],
    [ "psxlen", "structacvp__kas__ecc__tc__t.html#a378883f84be03a276811789d0c810aba", null ],
    [ "psy", "structacvp__kas__ecc__tc__t.html#ac727e080b34168d04a2bc57c9527bee4", null ],
    [ "psylen", "structacvp__kas__ecc__tc__t.html#a5527e34eba4c88d9fa364bea5e2cc8d1", null ],
    [ "test_type", "structacvp__kas__ecc__tc__t.html#ae4bb075eae77498f2563ff9a1d2955ba", null ],
    [ "z", "structacvp__kas__ecc__tc__t.html#ab275cb874bfd8775231594ef0986c7b9", null ],
    [ "zlen", "structacvp__kas__ecc__tc__t.html#a0dbae0464f702cabe3fca2905e9f5558", null ]
];