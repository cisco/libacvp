var structacvp__kdf135__srtp__tc__t =
[
    [ "aes_keylen", "structacvp__kdf135__srtp__tc__t.html#a17e1dce69092bb649d0c31eb1e35e46d", null ],
    [ "cipher", "structacvp__kdf135__srtp__tc__t.html#a75a4a0af12b65d03933e6837649bfd67", null ],
    [ "idx", "structacvp__kdf135__srtp__tc__t.html#a89025acaa92b00f8b061396c123146b8", null ],
    [ "kdr", "structacvp__kdf135__srtp__tc__t.html#aa3032919f9e47c31373e008576c18e07", null ],
    [ "kdr_len", "structacvp__kdf135__srtp__tc__t.html#ad796c465b7c4ef546485d4825f859390", null ],
    [ "master_key", "structacvp__kdf135__srtp__tc__t.html#aed6a02c9e7071f724111465bda2ec399", null ],
    [ "master_salt", "structacvp__kdf135__srtp__tc__t.html#a062c4c45c3259dcd3c933970ae75b422", null ],
    [ "srtcp_idx", "structacvp__kdf135__srtp__tc__t.html#a4ff8cc4859daa54975b59bf19acd761a", null ],
    [ "srtcp_ka", "structacvp__kdf135__srtp__tc__t.html#ad1335d3b4d7ca52692b9f5b279dc2189", null ],
    [ "srtcp_ke", "structacvp__kdf135__srtp__tc__t.html#a633ea38e62b45af30d284efc95f51a3d", null ],
    [ "srtcp_ks", "structacvp__kdf135__srtp__tc__t.html#a8e80ef50ac9f77149e34d790acfdd050", null ],
    [ "srtp_ka", "structacvp__kdf135__srtp__tc__t.html#a5193c30610d75403daa1bb22ab3854a2", null ],
    [ "srtp_ke", "structacvp__kdf135__srtp__tc__t.html#a355e48bc2c2b4ac94aa8d92dda41220e", null ],
    [ "srtp_ks", "structacvp__kdf135__srtp__tc__t.html#a4f168a17c99d898f10ea57c7533f7267", null ],
    [ "tc_id", "structacvp__kdf135__srtp__tc__t.html#a8e4a09916af1261452196ce51d3a26ff", null ]
];