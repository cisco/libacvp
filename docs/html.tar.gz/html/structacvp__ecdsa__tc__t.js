var structacvp__ecdsa__tc__t =
[
    [ "cipher", "structacvp__ecdsa__tc__t.html#a75a4a0af12b65d03933e6837649bfd67", null ],
    [ "curve", "structacvp__ecdsa__tc__t.html#aa7978ecfeaafd624eca35d005451c0eb", null ],
    [ "d", "structacvp__ecdsa__tc__t.html#afad87c230201dac06d616d41b2635c3d", null ],
    [ "d_len", "structacvp__ecdsa__tc__t.html#a56c2f899ac7594e64acb9860310ac25d", null ],
    [ "hash_alg", "structacvp__ecdsa__tc__t.html#a032714d211f50ac352cd006ba56caa71", null ],
    [ "message", "structacvp__ecdsa__tc__t.html#abb13456032cf48eaa794391b6ed937c7", null ],
    [ "msg_len", "structacvp__ecdsa__tc__t.html#a8c1640b5d7d30e041620721dda978214", null ],
    [ "qx", "structacvp__ecdsa__tc__t.html#a6b425a9a72ad77fa090479880afafba0", null ],
    [ "qx_len", "structacvp__ecdsa__tc__t.html#a1be05a5844a8facf211eaf20e2471abc", null ],
    [ "qy", "structacvp__ecdsa__tc__t.html#a7c50f8bba82cc9bd591e3b6c2249ca6d", null ],
    [ "qy_len", "structacvp__ecdsa__tc__t.html#a6575dd7b926a2c01fdbd402188ff7dae", null ],
    [ "r", "structacvp__ecdsa__tc__t.html#ad7fd5738a497c223b36ac54d723c7a37", null ],
    [ "r_len", "structacvp__ecdsa__tc__t.html#a5d98c48f180c5b5bd9bbb285551430be", null ],
    [ "s", "structacvp__ecdsa__tc__t.html#a671eca2e10f113e16cc4dda975f34de9", null ],
    [ "s_len", "structacvp__ecdsa__tc__t.html#a46521e4aa28bc9107871476dd0fa2c43", null ],
    [ "secret_gen_mode", "structacvp__ecdsa__tc__t.html#abd69ee096ae1f1d07265c616fff01619", null ],
    [ "tc_id", "structacvp__ecdsa__tc__t.html#a8e4a09916af1261452196ce51d3a26ff", null ],
    [ "tg_id", "structacvp__ecdsa__tc__t.html#a83a91cee09a57a02e57d3f9063de3167", null ],
    [ "ver_disposition", "structacvp__ecdsa__tc__t.html#a52ae6f2208f0254112687682ad491149", null ]
];