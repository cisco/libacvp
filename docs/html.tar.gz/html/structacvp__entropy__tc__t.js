var structacvp__entropy__tc__t =
[
    [ "cipher", "structacvp__entropy__tc__t.html#a75a4a0af12b65d03933e6837649bfd67", null ],
    [ "entropy_data", "structacvp__entropy__tc__t.html#a5015fa8f3c0c43d7f0caf9537ff8fcbf", null ],
    [ "entropy_len", "structacvp__entropy__tc__t.html#a6a53767bd23a6599a52e6ed0d1ba4cd3", null ],
    [ "tc_id", "structacvp__entropy__tc__t.html#a8e4a09916af1261452196ce51d3a26ff", null ]
];