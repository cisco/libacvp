var structacvp__kdf135__x963__tc__t =
[
    [ "cipher", "structacvp__kdf135__x963__tc__t.html#a75a4a0af12b65d03933e6837649bfd67", null ],
    [ "field_size", "structacvp__kdf135__x963__tc__t.html#a04de1be75b720fb2e2bab9f738c760a4", null ],
    [ "hash_alg", "structacvp__kdf135__x963__tc__t.html#a032714d211f50ac352cd006ba56caa71", null ],
    [ "key_data", "structacvp__kdf135__x963__tc__t.html#a8ee5a96de9cebebc948c4e637914d18c", null ],
    [ "key_data_len", "structacvp__kdf135__x963__tc__t.html#a8240847074e3259831cb1b82009c18a9", null ],
    [ "shared_info", "structacvp__kdf135__x963__tc__t.html#a1c0f432124a8982f9be20faeb1ad5870", null ],
    [ "shared_info_len", "structacvp__kdf135__x963__tc__t.html#a5a237576778e7dde55a10d15ab067fb2", null ],
    [ "tc_id", "structacvp__kdf135__x963__tc__t.html#a8e4a09916af1261452196ce51d3a26ff", null ],
    [ "z", "structacvp__kdf135__x963__tc__t.html#ab275cb874bfd8775231594ef0986c7b9", null ]
];